//
//  neobeacons_sdk_wrapper.h
//  neobeacons-sdk-wrapper
//
//  Created by G Six on 3/21/25.
//

#import <Foundation/Foundation.h>

//! Project version number for neobeacons_sdk_wrapper.
FOUNDATION_EXPORT double neobeacons_sdk_wrapperVersionNumber;

//! Project version string for neobeacons_sdk_wrapper.
FOUNDATION_EXPORT const unsigned char neobeacons_sdk_wrapperVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <neobeacons_sdk_wrapper/PublicHeader.h>


